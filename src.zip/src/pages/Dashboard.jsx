import React from 'react';
import { Container, Card } from 'react-bootstrap';
import 'chart.js/auto';
import '../pages/CSS/Dashboard.css';
import CustomTable from '../components/CustomTable';
import DonutChart from './DonutChart';
 
const stats = [
  {
    title: 'All Messages',
    value: 386,
    icon: 'bi-chat-dots',
    color: 'primary',
    change: '+12%',
    changeType: 'up',
  },
  {
    title: 'Media Messages',
    value: 26,
    icon: 'bi-file-earmark-image',
    color: 'info',
    change: '-5%',
    changeType: 'down',
  },
  {
    title: 'Text Messages',
    value: 17,
    icon: 'bi-chat-text',
    color: 'success',
    change: '+3%',
    changeType: 'up',
  },
  {
    title: 'Messages per day',
    value: 35.09,
    icon: 'bi-calendar3',
    color: 'warning',
    change: '+1.5%',
    changeType: 'up',
  },
  {
    title: 'No of days',
    value: 11,
    icon: 'bi-clock-history',
    color: 'danger',
    change: '0%',
    changeType: 'up',
  },
];
 
const MessageAnalysis = () => {
  return (
    <Container fluid className="p-4 responsive-padding mt-5 pt-5 pt-lg-0">
      <h4 className="heading mb-4 text-black">Message Analysis</h4>
 
      <div className="stat-scroll-wrapper">
        {stats.map((stat, idx) => (
  <div className="stat-card-small" key={stat.title}>
   <div className="card h-100 shadow-sm stat-card">
 
      <div className="card-body d-flex flex-column justify-content-between p-4">
        <div className="d-flex justify-content-between align-items-start">
          <div>
            <div className="fs-4 fw-semibold text-dark">{stat.value}</div>
            <div className="text-muted small">{stat.title}</div>
          </div>
          <div className={`stat-icon-lg bg-${stat.color}-subtle`}>
            <i className={`bi ${stat.icon} text-${stat.color} fs-5`}></i>
          </div>
        </div>
       {stat.change && (
  <div className="stat-badge-wrapper mt-3">
    <span className={`badge stat-badge bg-${stat.changeType === 'up' ? 'success' : 'danger'}`}>
      {stat.change}
      <i className={`bi bi-caret-${stat.changeType}-fill ms-1`}></i>
    </span>
  </div>
)}
      </div>
    </div>
  </div>
))}
 
 
       
            </div>
 
        {/* Start Date */}
        {/* <div className="stat-card-small">
          <div className="card h-100 shadow-sm-sm">
            <div className="card-body d-flex flex-column align-items-start p-3">
              <div className="text-muted small mb-1">Start Date</div>
              <input type="date" className="form-control form-control-sm" />
            </div>
          </div>
        </div> */}
 
        {/* End Date */}
        {/* <div className="stat-card-small">
          <div className="card h-100 shadow-sm-sm">
            <div className="card-body d-flex flex-column align-items-start p-3">
              <div className="text-muted small mb-1">End Date</div>
              <input type="date" className="form-control form-control-sm" />
            </div>
          </div>
        </div> */}
 
 
      {/* Layout */}
      <div className="analysis-layout mt-4">
        <div className="table-section">
          <CustomTable
            headers={['Name', 'Sent Messages', 'Read Messages', 'Not Delivered']}
            columns={['Name', 'SentMesseages', 'ReadMessages', 'NotDelivered']}
            data={[
              { Name: 'Alice', SentMesseages: 3, ReadMessages: 6, NotDelivered: 2 },
              { Name: 'Bob', SentMesseages: 8, ReadMessages: 7, NotDelivered: 1 },
              { Name: 'Charlie', SentMesseages: 10, ReadMessages: 9, NotDelivered: 0 },
              { Name: 'Daisy', SentMesseages: 5, ReadMessages: 3, NotDelivered: 2 },
              { Name: 'Ethan', SentMesseages: 7, ReadMessages: 5, NotDelivered: 2 },
              { Name: 'Fiona', SentMesseages: 4, ReadMessages: 2, NotDelivered: 2 },
              { Name: 'George', SentMesseages: 12, ReadMessages: 10, NotDelivered: 2 },
              { Name: 'Hannah', SentMesseages: 6, ReadMessages: 4, NotDelivered: 2 },
                { Name: 'Fiona', SentMesseages: 4, ReadMessages: 2, NotDelivered: 2 },
              { Name: 'George', SentMesseages: 12, ReadMessages: 10, NotDelivered: 2 },
              { Name: 'Hannah', SentMesseages: 6, ReadMessages: 4, NotDelivered: 2 }
            ]}
          />
        </div>
 
        <Card className="p-3 table-wrapper" style={{display:'flex' , justifyContent:'center',alignItems:'center'}}>
         
       <DonutChart />
        </Card>
      </div>
    </Container>
  );
};
 
export default MessageAnalysis;